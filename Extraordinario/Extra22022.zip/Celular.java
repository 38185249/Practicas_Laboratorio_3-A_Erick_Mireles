public class Celular{
	float procesador;
	public Celular(String float float){

	}
}