public class Computadora{
	int ram;
	public Computadora(String float int){

	}
}