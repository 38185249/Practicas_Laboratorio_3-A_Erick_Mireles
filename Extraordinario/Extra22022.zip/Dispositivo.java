public class Dispositivo {

	String marca;
	float costo;

	public Dispositivo(String float){

	}
}